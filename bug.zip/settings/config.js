const fs = require('fs')

const config = {
    owner: "6285867687134",
    botNumber: "6285867687134",
    setPair: "PRIMISV7",
    thumbUrl: "https://i.ibb.co/Z6981vZH/34c99a9d6cab.jpg",
    session: "sessions",
    self: false,
    status: {
        public: false,
        terminal: true,
        reactsw: false
    },
    message: {
owner: '*ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ᴜsᴇᴅ ᴏɴʟʏ ғᴏʀ ᴏᴡɴᴇʀ.*',
premium: '*ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ᴜsᴇᴅ ᴏɴʟʏ ғᴏʀ ᴘʀᴇᴍɪᴜᴍ.*',
succes: '*sᴜᴄᴄᴇssғᴜʟʟʏ.*',
group: '*ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ɪs ᴏɴʟʏ ᴜsᴇᴅ ɪɴ ɢʀᴏᴜᴘ.*',
admins: '*ᴛʜᴇ ʙᴏᴛ ᴍᴜsᴛ ʙᴇ ᴀᴅᴍɪɴ ᴏғ ᴛʜᴇ ɢʀᴏᴜᴘ.*'
    },
    settings: {
        title: "Primis",
        packname: '🩸⃟༑⌁⃰𝐏𝐫𝐢𝐦𝐢𝐬𝐁𝐮𝐠𝐕7ཀ🦠',
        description: "this script was created by ᴅׅ֮ꜱׁׅܻ݊ᴘׁׁׅʀ݊ɪׁׁׅᴍ݊ɪׁׁׅꜱ",
        author: 'DsPrimis',
        footer: "Primis - 2025"
    },
    newsletter: {
        name: "🩸⃟༑⌁⃰𝐏𝐫𝐢𝐦𝐢𝐬𝐁𝐮𝐠ཀ🦠",
        id: "120363419474272514@newsletter"
    },
    socialMedia: {
        YouTube: "https://youtube.com/@DevPrimis-z9e",
        GitHub: "https://github.com/dsprimis",
        Telegram: "https://t.me/dsprimis",
        ChannelWA: "https://whatsapp.com/channel/0029VbAqjwm1CYoTLEg7KR44"
    }
}

global.newsletterID = "120363419474272514@newsteller"
global.newsletterName = "🩸⃟༑⌁⃰𝐏𝐫𝐢𝐦𝐢𝐬𝐁𝐮𝐠ཀ🦠"

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
